package com.example.realisticterrain;

import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.BiomeProvider;
import net.minecraft.world.gen.IChunkGenerator;

public class WorldTypeRealistic extends WorldType {
    public WorldTypeRealistic() {
        super("realistic");
    }

    @Override
    public BiomeProvider getBiomeProvider(World world) {
        return new BiomeProviderRealistic(world.getSeed());
    }

    @Override
    public IChunkGenerator getChunkGenerator(World world, String generatorOptions) {
        return new ChunkGeneratorRealistic(world);
    }
}
