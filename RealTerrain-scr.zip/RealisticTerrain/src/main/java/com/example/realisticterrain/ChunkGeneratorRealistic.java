package com.example.realisticterrain;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.BlockFalling;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldEntitySpawner;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.MapGenBase;
import net.minecraft.world.gen.MapGenCaves;

public class ChunkGeneratorRealistic implements IChunkGenerator {
    private static final int SEA = TerrainNoise.SEA;
    private static final IBlockState STONE = Blocks.STONE.getDefaultState();
    private static final IBlockState BEDROCK = Blocks.BEDROCK.getDefaultState();
    private static final IBlockState WATER = Blocks.WATER.getDefaultState();
    private static final IBlockState SAND = Blocks.SAND.getDefaultState();
    private static final IBlockState GRAVEL = Blocks.GRAVEL.getDefaultState();
    private static final IBlockState DIRT = Blocks.DIRT.getDefaultState();
    private static final IBlockState SNOW = Blocks.SNOW.getDefaultState();

    private final World world;
    private final Random rand;
    private final TerrainNoise noise;
    private final CityGenerator cityGen;
    private final MapGenBase caves = new MapGenCaves();

    public ChunkGeneratorRealistic(World world) {
        this.world = world;
        this.rand = new Random(world.getSeed());
        this.noise = new TerrainNoise(world.getSeed());
        this.cityGen = new CityGenerator(world, noise);
    }

    @Override
    public Chunk generateChunk(int cx, int cz) {
        rand.setSeed((long) cx * 341873128712L + (long) cz * 132897987541L);
        ChunkPrimer primer = new ChunkPrimer();
        Biome[] biomes = new Biome[256];

        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = cx * 16 + dx, z = cz * 16 + dz;
                double[] s = noise.sample(x, z);
                Biome biome = noise.biome(x, z, s);
                biomes[dz * 16 + dx] = biome;
                int h = (int) Math.round(s[0]);
                h = Math.max(5, Math.min(250, h));
                buildColumn(primer, dx, dz, h, biome);
            }
        }

        caves.generate(world, cx, cz, primer);

        Chunk chunk = new Chunk(world, primer, cx, cz);
        byte[] arr = chunk.getBiomeArray();
        for (int i = 0; i < 256; i++) arr[i] = (byte) Biome.getIdForBiome(biomes[i]);
        chunk.generateSkylightMap();
        return chunk;
    }

    private void buildColumn(ChunkPrimer p, int dx, int dz, int h, Biome biome) {
        IBlockState top = biome.topBlock, fill = biome.fillerBlock;
        if (h < SEA) {
            boolean shallow = h > SEA - 8;
            top = shallow ? SAND : GRAVEL;
            fill = shallow ? SAND : DIRT;
        } else if (biome == Biomes.EXTREME_HILLS || biome == Biomes.ICE_MOUNTAINS) {
            if (h >= 118) { top = SNOW; fill = STONE; }
            else if (h >= 92) { top = STONE; fill = STONE; }
        }
        int fillDepth = 3 + rand.nextInt(2);
        for (int y = 0; y <= h; y++) {
            IBlockState st;
            if (y <= rand.nextInt(5)) {
                st = BEDROCK;
            } else {
                int depth = h - y;
                st = depth == 0 ? top : (depth <= fillDepth ? fill : STONE);
            }
            p.setBlockState(dx, y, dz, st);
        }
        for (int y = h + 1; y <= SEA; y++) p.setBlockState(dx, y, dz, WATER);
    }

    @Override
    public void populate(int cx, int cz) {
        BlockFalling.fallInstantly = true;
        int bx = cx * 16, bz = cz * 16;
        BlockPos pos = new BlockPos(bx, 0, bz);
        Biome biome = world.getBiome(pos.add(16, 0, 16));

        rand.setSeed(world.getSeed());
        long l1 = rand.nextLong() / 2L * 2L + 1L;
        long l2 = rand.nextLong() / 2L * 2L + 1L;
        rand.setSeed((long) cx * l1 + (long) cz * l2 ^ world.getSeed());

        biome.decorate(world, rand, pos); // trees, grass, flowers, ores, etc.

        TerrainNoise.CityInfo ci = noise.cityAt(bx + 16, bz + 16);
        if (ci != null && Math.hypot(bx + 16 - ci.cx, bz + 16 - ci.cz) <= ci.radius + 12) {
            cityGen.generate(bx + 8, bz + 8, ci); // roads, houses, stores...
        }

        WorldEntitySpawner.performWorldGenSpawning(world, biome, bx + 8, bz + 8, 16, 16, rand);

        pos = pos.add(8, 0, 8);
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                BlockPos precip = world.getPrecipitationHeight(pos.add(i, 0, j));
                BlockPos below = precip.down();
                if (world.canBlockFreezeWater(below)) world.setBlockState(below, Blocks.ICE.getDefaultState(), 2);
                if (world.canSnowAtBody(precip, true)) world.setBlockState(precip, Blocks.SNOW_LAYER.getDefaultState(), 2);
            }
        }
        BlockFalling.fallInstantly = false;
    }

    @Override
    public boolean generateStructures(Chunk chunkIn, int x, int z) {
        return false;
    }

    @Override
    public List<Biome.SpawnListEntry> getPossibleCreatures(EnumCreatureType type, BlockPos pos) {
        return world.getBiome(pos).getSpawnableList(type);
    }

    @Nullable
    @Override
    public BlockPos getNearestStructurePos(World worldIn, String name, BlockPos pos, boolean findUnexplored) {
        return null;
    }

    @Override
    public void recreateStructures(Chunk chunkIn, int x, int z) { }

    @Override
    public boolean isInsideStructure(World worldIn, String name, BlockPos pos) {
        return false;
    }
}
