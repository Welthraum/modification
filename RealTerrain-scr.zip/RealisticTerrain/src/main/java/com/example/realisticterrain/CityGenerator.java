package com.example.realisticterrain;

import java.util.Random;
import net.minecraft.block.BlockColored;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockOldLog;
import net.minecraft.block.BlockPlanks;
import net.minecraft.block.BlockStainedGlass;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.BlockWallSign;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemDoor;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

/**
 * Builds a US-style city: street grid, sidewalks, street lights, downtown (big box store,
 * offices, strip malls, parking lots) and suburbs (houses with driveways, parks).
 * Everything is deterministic per lot, and writes are clipped to the 16x16 area being populated,
 * so buildings line up perfectly across chunk borders.
 */
public class CityGenerator {
    private static final int P = 48;       // block period (road + lot)
    private static final int W = 11;       // road width incl. sidewalks
    private static final int S = P - W;    // lot size = 37

    private static IBlockState concrete(EnumDyeColor c) {
        return Blocks.CONCRETE.getDefaultState().withProperty(BlockColored.COLOR, c);
    }
    private static IBlockState planks(BlockPlanks.EnumType t) {
        return Blocks.PLANKS.getDefaultState().withProperty(BlockPlanks.VARIANT, t);
    }

    private static final IBlockState AIR = Blocks.AIR.getDefaultState();
    private static final IBlockState ASPHALT = concrete(EnumDyeColor.BLACK);
    private static final IBlockState SIDEWALK = concrete(EnumDyeColor.SILVER);
    private static final IBlockState DRIVE = concrete(EnumDyeColor.GRAY);
    private static final IBlockState YELLOW = concrete(EnumDyeColor.YELLOW);
    private static final IBlockState WHITE = concrete(EnumDyeColor.WHITE);
    private static final IBlockState BLUE = concrete(EnumDyeColor.BLUE);
    private static final IBlockState GLASS = Blocks.GLASS.getDefaultState();
    private static final IBlockState TINT = Blocks.STAINED_GLASS.getDefaultState().withProperty(BlockStainedGlass.COLOR, EnumDyeColor.LIGHT_BLUE);
    private static final IBlockState GRASS = Blocks.GRASS.getDefaultState();
    private static final IBlockState GLOW = Blocks.GLOWSTONE.getDefaultState();
    private static final IBlockState LANTERN = Blocks.SEA_LANTERN.getDefaultState();
    private static final IBlockState BARS = Blocks.IRON_BARS.getDefaultState();
    private static final IBlockState SHELF = Blocks.BOOKSHELF.getDefaultState();
    private static final IBlockState LOG = Blocks.LOG.getDefaultState().withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.OAK);
    private static final IBlockState LEAVES = Blocks.LEAVES.getDefaultState()
            .withProperty(BlockLeaves.CHECK_DECAY, false).withProperty(BlockLeaves.DECAYABLE, false);

    private static final IBlockState[] WALLS = {
            concrete(EnumDyeColor.WHITE), concrete(EnumDyeColor.SILVER), concrete(EnumDyeColor.LIGHT_BLUE),
            planks(BlockPlanks.EnumType.BIRCH), planks(BlockPlanks.EnumType.OAK), Blocks.BRICK_BLOCK.getDefaultState() };
    private static final IBlockState[] ROOF_STAIRS = {
            Blocks.SPRUCE_STAIRS.getDefaultState(), Blocks.BRICK_STAIRS.getDefaultState(), Blocks.STONE_BRICK_STAIRS.getDefaultState() };
    private static final IBlockState[] ROOF_SOLID = {
            planks(BlockPlanks.EnumType.SPRUCE), Blocks.BRICK_BLOCK.getDefaultState(), Blocks.STONEBRICK.getDefaultState() };

    private final World w;
    private final long seed;
    private int minX, minZ, gy;

    public CityGenerator(World world, TerrainNoise noise) {
        this.w = world;
        this.seed = world.getSeed();
    }

    // ---------- clipped helpers ----------
    private boolean inArea(int x, int z) {
        return x >= minX && x < minX + 16 && z >= minZ && z < minZ + 16;
    }

    private void set(int x, int y, int z, IBlockState s) {
        if (!inArea(x, z) || y < 1 || y > 255) return;
        w.setBlockState(new BlockPos(x, y, z), s, 2);
    }

    private void setSoft(int x, int y, int z, IBlockState s) {
        if (!inArea(x, z) || y < 1 || y > 255) return;
        BlockPos p = new BlockPos(x, y, z);
        if (w.isAirBlock(p)) w.setBlockState(p, s, 2);
    }

    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, IBlockState s) {
        int a = Math.max(Math.min(x1, x2), minX), b = Math.min(Math.max(x1, x2), minX + 15);
        int c = Math.max(Math.min(z1, z2), minZ), d = Math.min(Math.max(z1, z2), minZ + 15);
        int lo = Math.max(1, Math.min(y1, y2)), hi = Math.min(255, Math.max(y1, y2));
        for (int x = a; x <= b; x++)
            for (int z = c; z <= d; z++)
                for (int y = lo; y <= hi; y++)
                    w.setBlockState(new BlockPos(x, y, z), s, 2);
    }

    // ---------- main entry ----------
    public void generate(int ax, int az, TerrainNoise.CityInfo ci) {
        minX = ax; minZ = az; gy = ci.height;
        int R = ci.radius;

        // 1) clear trees / plants inside the city
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = ax + dx, z = az + dz;
                if (Math.hypot(x - ci.cx, z - ci.cz) > R) continue;
                for (int y = gy + 1; y <= gy + 24; y++) {
                    mp.setPos(x, y, z);
                    if (!w.isAirBlock(mp)) w.setBlockState(mp, AIR, 2);
                }
            }
        }

        // 2) roads, sidewalks, lane lines, street lights
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = ax + dx, z = az + dz;
                int lx = x - ci.cx, lz = z - ci.cz;
                if (Math.hypot(lx, lz) > R) continue;
                int u = Math.floorMod(lx, P), v = Math.floorMod(lz, P);
                boolean rx = u < W, rz = v < W;
                if (!rx && !rz) continue;
                boolean uEdge = (u == 0 || u == W - 1), vEdge = (v == 0 || v == W - 1);
                IBlockState b;
                if (rx && rz) {
                    b = (uEdge && vEdge) ? SIDEWALK : ASPHALT;
                } else if (rx) {
                    b = uEdge ? SIDEWALK : ((u == W / 2 && Math.floorMod(lz, 4) < 2) ? YELLOW : ASPHALT);
                    if ((u == 0 && Math.floorMod(lz, 16) == 8) || (u == W - 1 && Math.floorMod(lz, 16) == 0)) lamp(x, z);
                } else {
                    b = vEdge ? SIDEWALK : ((v == W / 2 && Math.floorMod(lx, 4) < 2) ? YELLOW : ASPHALT);
                    if ((v == 0 && Math.floorMod(lx, 16) == 8) || (v == W - 1 && Math.floorMod(lx, 16) == 0)) lamp(x, z);
                }
                set(x, gy, z, b);
            }
        }

        // 3) lots
        int li0 = Math.floorDiv(ax - ci.cx, P) - 1, li1 = Math.floorDiv(ax + 15 - ci.cx, P);
        int lj0 = Math.floorDiv(az - ci.cz, P) - 1, lj1 = Math.floorDiv(az + 15 - ci.cz, P);
        for (int li = li0; li <= li1; li++) {
            for (int lj = lj0; lj <= lj1; lj++) {
                int ox = ci.cx + li * P + W, oz = ci.cz + lj * P + W;
                if (ox + S - 1 < ax || ox > ax + 15 || oz + S - 1 < az || oz > az + 15) continue;
                double dcen = Math.hypot(ox + S / 2.0 - ci.cx, oz + S / 2.0 - ci.cz);
                if (dcen > R - 20) continue;
                buildLot(li, lj, ox, oz, dcen / R, ci);
            }
        }
    }

    private void buildLot(int li, int lj, int ox, int oz, double q, TerrainNoise.CityInfo ci) {
        Random r = new Random(seed ^ (ci.cx * 73856093L) ^ (ci.cz * 19349663L) ^ (li * 83492791L) ^ (lj * 2654435761L));
        r.nextInt(); r.nextInt();
        double roll = r.nextDouble();
        int type; // 0 houses, 1 big box, 2 office, 3 strip mall, 4 parking, 5 park
        if (li == 0 && lj == 0) type = 1;
        else if (q < 0.45) type = roll < 0.15 ? 1 : roll < 0.45 ? 2 : roll < 0.75 ? 3 : 4;
        else if (q < 0.75) type = roll < 0.85 ? 0 : 5;
        else type = roll < 0.70 ? 0 : 5;

        switch (type) {
            case 0: houses(ox, oz, r); break;
            case 1: bigBox(ox, oz, r); break;
            case 2: office(ox, oz, r); break;
            case 3: stripMall(ox, oz, r); break;
            case 4: lawn(ox, oz); parkingLot(ox, oz, 0, r); break;
            default: park(ox, oz, r); break;
        }
    }

    // ---------- small pieces ----------
    private void lamp(int x, int z) {
        fill(x, gy + 1, z, x, gy + 5, z, BARS);
        set(x, gy + 6, z, LANTERN);
    }

    private void lawn(int ox, int oz) {
        fill(ox, gy, oz, ox + S - 1, gy, oz + S - 1, GRASS);
    }

    private void tree(int x, int z, int h) {
        for (int y = 1; y <= h; y++) setSoft(x, gy + y, z, LOG);
        for (int dy = h - 2; dy <= h + 1; dy++) {
            int rad = dy >= h ? 1 : 2;
            for (int dx = -rad; dx <= rad; dx++) {
                for (int dz = -rad; dz <= rad; dz++) {
                    if (rad == 2 && Math.abs(dx) == 2 && Math.abs(dz) == 2) continue;
                    if (dx == 0 && dz == 0 && dy <= h) continue;
                    setSoft(x + dx, gy + dy, z + dz, LEAVES);
                }
            }
        }
    }

    private void wallSign(int x, int y, int z, String l1, String l2) {
        if (!inArea(x, z)) return;
        BlockPos p = new BlockPos(x, y, z);
        IBlockState st = Blocks.WALL_SIGN.getDefaultState().withProperty(BlockWallSign.FACING, EnumFacing.SOUTH);
        w.setBlockState(p, st, 2);
        TileEntity te = w.getTileEntity(p);
        if (te instanceof TileEntitySign) {
            TileEntitySign sign = (TileEntitySign) te;
            sign.signText[1] = new TextComponentString(l1);
            sign.signText[2] = new TextComponentString(l2);
            sign.markDirty();
            w.notifyBlockUpdate(p, st, st, 3);
        }
    }

    // ---------- parking ----------
    private void parkingLot(int ox, int oz, int z0, Random r) {
        fill(ox, gy, oz + z0, ox + S - 1, gy, oz + S - 1, ASPHALT);
        for (int zo = z0; zo < S; zo++) {
            int p = (zo - z0) % 15;
            boolean stall = (p >= 1 && p <= 5) || (p >= 10 && p <= 14);
            if (!stall) continue;
            for (int xo = 0; xo < S; xo += 4) set(ox + xo, gy, oz + zo, WHITE);
        }
        for (int m = 0; m < 3; m++) {
            for (int row = 0; row < 2; row++) {
                int zs = z0 + 15 * m + (row == 0 ? 1 : 10);
                for (int k = 0; k < 9; k++) {
                    boolean car = r.nextInt(100) < 40;
                    int col = r.nextInt(16);
                    if (!car || zs + 2 >= S) continue;
                    int cx0 = ox + 4 * k + 1;
                    fill(cx0, gy + 1, oz + zs, cx0 + 1, gy + 1, oz + zs + 2, concrete(EnumDyeColor.byMetadata(col)));
                    fill(cx0, gy + 2, oz + zs + 1, cx0 + 1, gy + 2, oz + zs + 1, GLASS);
                }
            }
        }
        if (z0 + 5 < S) {
            lamp(ox + 12, oz + z0 + 5);
            lamp(ox + 28, oz + z0 + 5);
        }
    }

    // ---------- Walmart-style big box ----------
    private void bigBox(int ox, int oz, Random r) {
        lawn(ox, oz);
        parkingLot(ox, oz, 18, r);
        int x1 = ox + 5, x2 = ox + 31, z1 = oz + 1, z2 = oz + 16;
        IBlockState gray = concrete(EnumDyeColor.GRAY);

        fill(x1, gy, z1, x2, gy, z2, gray);                         // floor
        fill(x1, gy + 1, z1, x2, gy + 8, z2, WHITE);                // walls
        fill(x1 + 1, gy + 1, z1 + 1, x2 - 1, gy + 8, z2 - 1, AIR);  // hollow
        fill(x1, gy + 6, z2, x2, gy + 8, z2, BLUE);                 // blue band on front
        fill(x1, gy + 9, z1, x2, gy + 9, z2, gray);                 // roof
        fill(x1, gy + 10, z1, x2, gy + 10, z1, gray);               // parapet
        fill(x1, gy + 10, z2, x2, gy + 10, z2, gray);
        fill(x1, gy + 10, z1, x1, gy + 10, z2, gray);
        fill(x2, gy + 10, z1, x2, gy + 10, z2, gray);

        fill(x1 + 2, gy + 3, z2, x1 + 8, gy + 4, z2, GLASS);        // front windows
        fill(x2 - 8, gy + 3, z2, x2 - 2, gy + 4, z2, GLASS);
        fill(ox + 16, gy + 1, z2, ox + 20, gy + 4, z2, AIR);        // entrance
        fill(x1, gy, z2 + 1, x2, gy, z2 + 1, SIDEWALK);             // sidewalk in front

        int[] shelfX = { ox + 8, ox + 11, ox + 25, ox + 28 };       // aisles
        for (int sx : shelfX) fill(sx, gy + 1, z1 + 2, sx, gy + 2, z2 - 3, SHELF);
        int[] lx = { ox + 9, ox + 15, ox + 21, ox + 27 };           // ceiling lights
        for (int xx : lx) { set(xx, gy + 8, oz + 4, GLOW); set(xx, gy + 8, oz + 11, GLOW); }

        wallSign(ox + 18, gy + 7, z2 + 1, "WALMART", "SUPERCENTER");
    }

    // ---------- strip mall ----------
    private void stripMall(int ox, int oz, Random r) {
        lawn(ox, oz);
        parkingLot(ox, oz, 18, r);
        int x1 = ox + 2, x2 = ox + 34, z1 = oz + 2, z2 = oz + 11;
        IBlockState wall = r.nextBoolean() ? Blocks.BRICK_BLOCK.getDefaultState() : WHITE;
        IBlockState gray = concrete(EnumDyeColor.GRAY);

        fill(x1, gy, z1, x2, gy, z2, gray);
        fill(x1, gy + 1, z1, x2, gy + 5, z2, wall);
        fill(x1 + 1, gy + 1, z1 + 1, x2 - 1, gy + 5, z2 - 1, AIR);
        fill(x1, gy + 6, z1, x2, gy + 6, z2, gray);
        fill(x1, gy + 7, z2, x2, gy + 7, z2, gray);
        for (int u = 0; u < 4; u++) {
            int x0 = x1 + 1 + 8 * u;
            EnumDyeColor col = EnumDyeColor.byMetadata(r.nextInt(16));
            fill(x0, gy + 4, z2, x0 + 7, gy + 5, z2, concrete(col)); // sign band
            fill(x0, gy + 2, z2, x0 + 3, gy + 3, z2, GLASS);         // shop window
            fill(x0 + 5, gy + 1, z2, x0 + 6, gy + 3, z2, AIR);       // door gap
            set(x0 + 3, gy + 5, z1 + 4, GLOW);
            set(x0 + 3, gy + 5, z1 + 7, GLOW);
        }
        fill(x1, gy, z2 + 1, x2, gy, z2 + 2, SIDEWALK);
    }

    // ---------- office tower ----------
    private void office(int ox, int oz, Random r) {
        lawn(ox, oz);
        fill(ox + 3, gy, oz + 3, ox + 33, gy, oz + 33, SIDEWALK);
        int floors = 5 + r.nextInt(8);
        int x1 = ox + 10, x2 = ox + 26, z1 = oz + 10, z2 = oz + 26;
        int top = gy + 4 * floors;
        IBlockState gray = concrete(EnumDyeColor.GRAY);

        fill(x1, gy, z1, x2, gy, z2, gray);
        fill(x1, gy + 1, z1, x2, top - 1, z2, TINT);
        fill(x1 + 1, gy + 1, z1 + 1, x2 - 1, top - 1, z2 - 1, AIR);
        for (int f = 1; f <= floors; f++) fill(x1, gy + 4 * f, z1, x2, gy + 4 * f, z2, gray);
        fill(x1, gy + 1, z1, x1, top, z1, gray);                  // corner pillars
        fill(x2, gy + 1, z1, x2, top, z1, gray);
        fill(x1, gy + 1, z2, x1, top, z2, gray);
        fill(x2, gy + 1, z2, x2, top, z2, gray);
        for (int f = 1; f <= floors; f++) {                       // lights under each ceiling
            int y = gy + 4 * f - 1;
            set(x1 + 4, y, z1 + 4, LANTERN); set(x2 - 4, y, z1 + 4, LANTERN);
            set(x1 + 4, y, z2 - 4, LANTERN); set(x2 - 4, y, z2 - 4, LANTERN);
        }
        fill(x1 + 7, gy + 1, z2, x1 + 9, gy + 3, z2, AIR);        // lobby entrance
        fill((x1 + x2) / 2, top + 1, (z1 + z2) / 2, (x1 + x2) / 2, top + 6, (z1 + z2) / 2, BARS);
    }

    // ---------- park with fountain ----------
    private void park(int ox, int oz, Random r) {
        lawn(ox, oz);
        fill(ox + 17, gy, oz, ox + 19, gy, oz + S - 1, SIDEWALK);
        fill(ox, gy, oz + 17, ox + S - 1, gy, oz + 19, SIDEWALK);
        int cx = ox + 18, cz = oz + 18;
        fill(cx - 3, gy, cz - 3, cx + 3, gy, cz + 3, Blocks.STONEBRICK.getDefaultState());
        fill(cx - 2, gy, cz - 2, cx + 2, gy, cz + 2, Blocks.WATER.getDefaultState());
        set(cx, gy + 1, cz, Blocks.STONEBRICK.getDefaultState());
        for (int i = 0; i < 12; i++) {
            int x = ox + 2 + r.nextInt(S - 4), z = oz + 2 + r.nextInt(S - 4), h = 4 + r.nextInt(3);
            if (Math.abs(x - cx) <= 2 || Math.abs(z - cz) <= 2) continue;
            tree(x, z, h);
        }
    }

    // ---------- suburbs ----------
    private void houses(int ox, int oz, Random r) {
        lawn(ox, oz);
        for (int a = 0; a < 2; a++)
            for (int b = 0; b < 2; b++)
                house(ox + a * 19, oz + b * 19, b == 0, r);
    }

    private void house(int px, int pz, boolean frontNeg, Random r) {
        IBlockState wall = WALLS[r.nextInt(WALLS.length)];
        int roofIdx = r.nextInt(3);
        int tx = px + 4 + r.nextInt(10);
        int treeH = 4 + r.nextInt(2);
        boolean hasTree = r.nextInt(100) < 70;

        int x1 = px + 5, x2 = px + 15;
        int z1 = frontNeg ? pz + 6 : pz + 3;
        int z2 = z1 + 8;
        int zm = z1 + 4;
        int frontZ = frontNeg ? z1 : z2;
        int out = frontNeg ? -1 : 1;
        int frontEdge = frontNeg ? pz : pz + 17;
        int doorX = x1 + 5;

        // driveway + front walk
        fill(px + 1, gy, Math.min(frontEdge, frontZ), px + 3, gy, Math.max(frontEdge, frontZ), DRIVE);
        fill(doorX, gy, Math.min(frontZ + out, frontEdge), doorX, gy, Math.max(frontZ + out, frontEdge), SIDEWALK);

        // shell
        fill(x1, gy, z1, x2, gy, z2, planks(BlockPlanks.EnumType.OAK));
        fill(x1, gy + 1, z1, x2, gy + 4, z2, wall);
        fill(x1 + 1, gy + 1, z1 + 1, x2 - 1, gy + 4, z2 - 1, AIR);

        // windows
        fill(x1 + 2, gy + 2, z1, x1 + 2, gy + 3, z1, GLASS);
        fill(x1 + 8, gy + 2, z1, x1 + 8, gy + 3, z1, GLASS);
        fill(x1 + 2, gy + 2, z2, x1 + 2, gy + 3, z2, GLASS);
        fill(x1 + 8, gy + 2, z2, x1 + 8, gy + 3, z2, GLASS);
        fill(x1, gy + 2, zm, x1, gy + 3, zm, GLASS);
        fill(x2, gy + 2, zm, x2, gy + 3, zm, GLASS);

        // door
        fill(doorX, gy + 1, frontZ, doorX, gy + 2, frontZ, AIR);
        if (inArea(doorX, frontZ)) {
            ItemDoor.placeDoor(w, new BlockPos(doorX, gy + 1, frontZ),
                    frontNeg ? EnumFacing.NORTH : EnumFacing.SOUTH, Blocks.OAK_DOOR, false);
        }

        // interior
        set(x1 + 1, gy + 1, z1 + 1, Blocks.TORCH.getDefaultState());
        set(x2 - 1, gy + 1, z2 - 1, Blocks.TORCH.getDefaultState());
        set(x2 - 1, gy + 1, zm, Blocks.CRAFTING_TABLE.getDefaultState());
        set(x1 + 1, gy + 1, zm, Blocks.FURNACE.getDefaultState());

        // gable roof (ridge runs along x)
        IBlockState stairN = ROOF_STAIRS[roofIdx].withProperty(BlockStairs.FACING, EnumFacing.NORTH);
        IBlockState stairS = ROOF_STAIRS[roofIdx].withProperty(BlockStairs.FACING, EnumFacing.SOUTH);
        int a = z1 - 1, b = z2 + 1, k = 0;
        while (a <= b) {
            int y = gy + 5 + k;
            if (a == b) {
                fill(x1, y, a, x2, y, a, ROOF_SOLID[roofIdx]);
            } else {
                fill(x1, y, a, x2, y, a, stairS);
                fill(x1, y, b, x2, y, b, stairN);
                if (a + 1 <= b - 1) fill(x1, y, a + 1, x2, y, b - 1, ROOF_SOLID[roofIdx]);
            }
            a++; b--; k++;
        }

        // back-yard tree
        if (hasTree) tree(tx, frontNeg ? pz + 16 : pz + 1, treeH);
    }
}
