package com.example.realisticterrain;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeProvider;

public class BiomeProviderRealistic extends BiomeProvider {
    private final TerrainNoise noise;

    public BiomeProviderRealistic(long seed) {
        super();
        this.noise = new TerrainNoise(seed);
    }

    @Override
    public Biome getBiome(BlockPos pos, Biome defaultBiome) {
        return noise.biomeAt(pos.getX(), pos.getZ());
    }

    @Override
    public Biome[] getBiomesForGeneration(Biome[] biomes, int x, int z, int width, int height) {
        return fill(biomes, x, z, width, height);
    }

    @Override
    public Biome[] getBiomes(@Nullable Biome[] listToReuse, int x, int z, int width, int length, boolean cacheFlag) {
        return fill(listToReuse, x, z, width, length);
    }

    private Biome[] fill(Biome[] arr, int x, int z, int w, int l) {
        if (arr == null || arr.length < w * l) arr = new Biome[w * l];
        for (int i = 0; i < w; i++)
            for (int j = 0; j < l; j++)
                arr[i + j * w] = noise.biomeAt(x + i, z + j);
        return arr;
    }

    @Override
    public boolean areBiomesViable(int x, int z, int radius, List<Biome> allowed) {
        return allowed.contains(noise.biomeAt(x, z));
    }

    /** Used for world spawn: find dry land that isn't a mountain top. */
    @Override
    @Nullable
    public BlockPos findBiomePosition(int x, int z, int range, List<Biome> biomes, Random random) {
        for (int r = 0; r <= 2048; r += 32) {
            for (int dx = -r; dx <= r; dx += 32) {
                for (int dz = -r; dz <= r; dz += 32) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                    int px = x + dx, pz = z + dz;
                    double[] s = noise.sample(px, pz);
                    if (s[0] >= TerrainNoise.SEA + 3 && s[0] < 90 && s[1] < 0.05) {
                        return new BlockPos(px, 0, pz);
                    }
                }
            }
        }
        return null;
    }
}
