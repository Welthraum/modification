package com.example.realisticterrain;

import java.util.Random;
import net.minecraft.init.Biomes;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.NoiseGeneratorSimplex;

/** All terrain + climate math lives here so chunk generator and biome provider always agree. */
public class TerrainNoise {
    public static final int SEA = 63;

    // Tweak these to change the look of the world:
    private static final double CONTINENT_SCALE = 1500.0; // bigger = larger continents/oceans
    private static final double MOUNTAIN_HEIGHT = 110.0;  // max extra height of mountain ridges
    private static final double RIVER_SCALE = 600.0;
    private static final double RIVER_WIDTH = 0.035;      // bigger = wider rivers

    private final NoiseGeneratorSimplex[] continent, mountMask, ridge, hills, river, temp, moist;
    private final long seed;
    private final java.util.concurrent.ConcurrentHashMap<Long, CityInfo> cities = new java.util.concurrent.ConcurrentHashMap<Long, CityInfo>();

    public TerrainNoise(long seed) {
        this.seed = seed;
        Random r = new Random(seed);
        continent = make(r, 4);
        mountMask = make(r, 3);
        ridge = make(r, 5);
        hills = make(r, 4);
        river = make(r, 3);
        temp = make(r, 3);
        moist = make(r, 3);
    }

    private static NoiseGeneratorSimplex[] make(Random r, int octaves) {
        NoiseGeneratorSimplex[] a = new NoiseGeneratorSimplex[octaves];
        for (int i = 0; i < octaves; i++) a[i] = new NoiseGeneratorSimplex(r);
        return a;
    }

    private static double fbm(NoiseGeneratorSimplex[] n, double x, double z) {
        double sum = 0, amp = 1, freq = 1, norm = 0;
        for (NoiseGeneratorSimplex o : n) {
            sum += o.getValue(x * freq, z * freq) * amp;
            norm += amp;
            amp *= 0.5;
            freq *= 2.0;
        }
        return sum / norm;
    }

    private static double clamp(double v, double lo, double hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private static double smooth(double t) {
        t = clamp(t, 0, 1);
        return t * t * (3 - 2 * t);
    }

    /** returns {height, riverStrength(0..1), continentValue(-1..1), mountainBonus} */
    public double[] sampleRaw(int x, int z) {
        double c = clamp(fbm(continent, x / CONTINENT_SCALE, z / CONTINENT_SCALE) * 2.2, -1, 1);
        double land = smooth((c + 0.15) * 4);

        double base = 64 + c * 30;
        if (c < -0.2) base -= (-0.2 - c) * 60; // deeper oceans

        double mask = clamp(fbm(mountMask, x / 900.0, z / 900.0) * 2.5 - 0.1, 0, 1);
        double ridged = clamp(1 - Math.abs(fbm(ridge, x / 260.0, z / 260.0) * 2.0), 0, 1);
        ridged *= ridged;
        double mount = mask * ridged * MOUNTAIN_HEIGHT * smooth((c - 0.1) * 3);

        double hill = fbm(hills, x / 70.0, z / 70.0) * 14 * land;

        double h = base + mount + hill;

        double rv = Math.abs(fbm(river, x / RIVER_SCALE, z / RIVER_SCALE));
        double t = rv < RIVER_WIDTH ? smooth(1 - rv / RIVER_WIDTH) : 0;
        t *= land * (1 - clamp(mount / 50.0, 0, 1));
        if (t > 0) {
            double bed = SEA - 3;
            h = h + (bed - h) * clamp(t * 1.5, 0, 1);
        }
        return new double[] { h, t, c, mount };
    }

    public double temperature(int x, int z, double h) {
        double t = 0.55 + fbm(temp, x / 1100.0, z / 1100.0) * 1.1;
        if (h > SEA) t -= (h - SEA) * 0.006; // colder with altitude
        return t;
    }

    public double moisture(int x, int z) {
        return 0.5 + fbm(moist, x / 800.0, z / 800.0) * 1.1;
    }

    public Biome biome(int x, int z, double[] s) {
        double h = s[0], riverT = s[1], c = s[2];
        double t = temperature(x, z, h);
        double m = moisture(x, z);
        boolean frozen = t < 0.15;

        if (h < SEA) {
            if (riverT > 0.25 && c > -0.05) return frozen ? Biomes.FROZEN_RIVER : Biomes.RIVER;
            if (h < SEA - 20) return Biomes.DEEP_OCEAN;
            return frozen ? Biomes.FROZEN_OCEAN : Biomes.OCEAN;
        }
        if (c < 0.1 && h <= SEA + 3) return frozen ? Biomes.COLD_BEACH : Biomes.BEACH;
        if (h > 105) return t < 0.1 ? Biomes.ICE_MOUNTAINS : Biomes.EXTREME_HILLS;
        if (h <= SEA + 5 && m > 0.62 && t > 0.35 && c > 0.05) return Biomes.SWAMPLAND;

        if (t < 0.15) return m < 0.45 ? Biomes.ICE_PLAINS : Biomes.COLD_TAIGA;
        if (t < 0.35) return m > 0.4 ? Biomes.TAIGA : Biomes.PLAINS;
        if (t < 0.7) {
            if (m > 0.68) return Biomes.ROOFED_FOREST;
            if (m > 0.58) return Biomes.BIRCH_FOREST;
            if (m > 0.45) return Biomes.FOREST;
            return Biomes.PLAINS;
        }
        if (m < 0.3) return Biomes.DESERT;
        if (m < 0.55) return Biomes.SAVANNA;
        return Biomes.JUNGLE;
    }

    public Biome biomeAt(int x, int z) {
        return biome(x, z, sample(x, z));
    }

    // ================= CITIES =================
    public static final int CELL = 512;            // one possible city per 512x512 cell
    private static final double CITY_CHANCE = 0.45; // chance a cell gets a city

    public static class CityInfo {
        public final int cx, cz, radius, height;
        CityInfo(int cx, int cz, int radius, int height) {
            this.cx = cx; this.cz = cz; this.radius = radius; this.height = height;
        }
    }
    private static final CityInfo NONE = new CityInfo(0, 0, 0, 0);

    public CityInfo cityAt(int x, int z) {
        int cellX = Math.floorDiv(x, CELL), cellZ = Math.floorDiv(z, CELL);
        long key = ((long) cellX << 32) ^ (cellZ & 0xffffffffL);
        CityInfo ci = cities.get(key);
        if (ci == null) {
            ci = makeCity(cellX, cellZ);
            cities.put(key, ci);
        }
        return ci == NONE ? null : ci;
    }

    private CityInfo makeCity(int cellX, int cellZ) {
        Random r = new Random(seed ^ (cellX * 341873128712L) ^ (cellZ * 132897987541L) ^ 0x5DEECE66DL);
        r.nextInt();
        if (r.nextDouble() > CITY_CHANCE) return NONE;
        int cx = cellX * CELL + 200 + r.nextInt(113);
        int cz = cellZ * CELL + 200 + r.nextInt(113);
        int radius = 110 + r.nextInt(61);

        double[] c = sampleRaw(cx, cz);
        if (c[2] < 0.05 || c[3] > 15) return NONE;
        double min = c[0], max = c[0], sum = c[0];
        int n = 1, reach = radius + 24;
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            double[] s = sampleRaw(cx + (int) (Math.cos(a) * reach), cz + (int) (Math.sin(a) * reach));
            if (s[0] < SEA + 2 || s[3] > 15) return NONE;
            min = Math.min(min, s[0]); max = Math.max(max, s[0]); sum += s[0]; n++;
        }
        if (max - min > 24) return NONE; // too hilly
        int height = (int) Math.round(sum / n);
        height = Math.max(SEA + 4, Math.min(88, height));
        return new CityInfo(cx, cz, radius, height);
    }

    /** Terrain sample including city flattening. */
    public double[] sample(int x, int z) {
        double[] s = sampleRaw(x, z);
        CityInfo ci = cityAt(x, z);
        if (ci != null) {
            double d = Math.hypot(x - ci.cx, z - ci.cz);
            if (d < ci.radius + 24) {
                double w = d <= ci.radius ? 1.0 : smooth(1 - (d - ci.radius) / 24.0);
                s[0] = s[0] + (ci.height - s[0]) * w;
                s[1] *= (1 - w);
                s[3] *= (1 - w);
            }
        }
        return s;
    }
}
