package com.example.realisticterrain;

import net.minecraft.world.WorldType;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = RealisticTerrain.MODID, name = "Realistic Terrain", version = "1.1.0", acceptedMinecraftVersions = "[1.12.2]")
public class RealisticTerrain {
    public static final String MODID = "realisticterrain";
    public static WorldType REALISTIC;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        REALISTIC = new WorldTypeRealistic();
    }
}
