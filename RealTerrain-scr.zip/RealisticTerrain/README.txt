Realistic Terrain v1.1 (Forge 1.12.2) - terrain + US-style cities

EASIEST WAY TO GET THE .JAR (no setup on your PC):
1. Make a free GitHub account, create a new repository, and upload everything from this zip
   (drag & drop the files, including the hidden .github folder).
2. Open the "Actions" tab -> "Build mod jar" -> wait ~5-10 min until it turns green.
3. Click the run -> download artifact "RealisticTerrain-jar" -> unzip -> put the .jar into .minecraft/mods
   (Forge 1.12.2 must be installed).

World: Create New World -> press "World Type" until "Realistic Terrain".
Cities: flat areas with grid roads, street lights, big-box "WALMART SUPERCENTER" + parking lots,
strip malls, office towers, suburbs with houses/driveways, and parks. Look for them on land
(about 1 per 512x512 area, so explore!).
